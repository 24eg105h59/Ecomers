const notFound = (req, res, next) => {
  const error = new Error(`Not Found - ${req.originalUrl}`);
  res.status(404);
  next(error);
};

const errorHandler = (err, req, res, next) => {
  let statusCode = res.statusCode !== 200 ? res.statusCode : 500;
  let message = err.message || 'Server Error';

  if (err.name === 'CastError') { statusCode = 404; message = 'Resource not found'; }
  if (err.name === 'ValidationError') { statusCode = 400; message = Object.values(err.errors).map(e => e.message).join(', '); }
  if (err.code === 11000) { statusCode = 400; message = `Duplicate value: ${Object.keys(err.keyValue).join(', ')}`; }

  res.status(statusCode).json({ message, stack: process.env.NODE_ENV === 'production' ? undefined : err.stack });
};

module.exports = { notFound, errorHandler };
